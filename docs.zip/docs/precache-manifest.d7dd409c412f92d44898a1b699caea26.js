self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "65b5fbd71a12981d9f7c9ebc37ede308",
    "url": "/index.html"
  },
  {
    "revision": "e429c485dcdb76f0699b",
    "url": "/static/css/main.bb72154b.chunk.css"
  },
  {
    "revision": "dec19ac107239610e4fa",
    "url": "/static/js/2.04f65b6c.chunk.js"
  },
  {
    "revision": "b4cabae32341920cfb4131dbdebda2c2",
    "url": "/static/js/2.04f65b6c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e429c485dcdb76f0699b",
    "url": "/static/js/main.79d079ac.chunk.js"
  },
  {
    "revision": "463330fbace4360efa59",
    "url": "/static/js/runtime-main.33fff6a5.js"
  }
]);